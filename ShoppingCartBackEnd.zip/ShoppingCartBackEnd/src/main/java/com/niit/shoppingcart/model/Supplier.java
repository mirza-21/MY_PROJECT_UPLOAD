package com.niit.shoppingcart.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Entity
@Table(name="SUPPLIER")
@Component
public class Supplier implements Serializable{
	
	
	private String id;
	
	private String name;
	
	private String address;
	
	private Set<Product> products;

	@Id
	@Column(name="ID")
	public String getId() {
		return id;
	}
	
	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@OneToMany(mappedBy = "supplier", fetch = FetchType.EAGER)
	public Set<Product> getProducts() {
		return products;
	}

	public  void setId(String id) {
		this.id = id;
	}

	@Column(name="NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name="ADDRESS")
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

}
