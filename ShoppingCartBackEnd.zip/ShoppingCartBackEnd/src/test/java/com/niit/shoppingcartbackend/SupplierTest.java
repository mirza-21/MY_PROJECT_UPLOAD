package com.niit.shoppingcartbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();

		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");

		Supplier supplier = (Supplier) context.getBean("supplier");
		
		List<Supplier> list = supplierDAO.list();
		for(Supplier s : list)
		{
			System.out.println(s.getId() + ":" + s.getName() + ":" + s.getAddress());
		}

		/*supplier.setId("SUP001");

		supplier.setName("SUPName02");
		supplier.setAddress("Kolkata");
		System.out.println(supplier.getId());

		supplierDAO.saveOrUpdate(supplier);
		System.out.println("s3");

		System.out.println("Supllier saved successfully");*/
		/* List<Supplier> l=supplierDAO.list();
		 for(Supplier c:l)
		 {
			 System.out.println();
			 System.out.println();
			 System.out.println();
		 }
*/

		/*
		 * System.out.println(supplier.getId());
		 * 
		 * supplierDAO.delete(supplier); 
		 * System.out.println("s3");
		 * 
		 * System.out.println("Supllier deleted");
		 */
	}

}