package com.niit.shoppingcartbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();

		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");

		/*user.setId("bharat23");
		System.out.println("u1");

		user.setName("Bharat kumar");
		System.out.println("u2");

		user.setPassword("12345");
		System.out.println("u3");
		
		user.setRepassword("12345");
		
		user.setMobile("9040822365");
		System.out.println("u4");

		user.setEmail("bharat23@gmail.com");
		System.out.println("u5");
		
		user.setRole("user");
		
		user.setEnabled(true);
		
		System.out.println(user.getId());
		System.out.println("u7");

		userDAO.saveOrUpdate(user);
		System.out.println("u8");

		System.out.println("User saved");*/
		
		/*List<User> list = userDAO.list();
		for(User u : list)
		{
			System.out.println( u.getId() + ":" + u.getName() + ":" + u.getPassword() + ":" + u.getMobile() + ":" + u.getEmail()+ ":" + u.getRepassword());
		}*/
		
	}
	
}
