package com.niit.shoppingcartbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit");

		context.refresh();

		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");

		/*product.setId("PR044");

		product.setName("Lenovo");
		
		product.setDescription("This is Lenovo k3");
		
		product.setPrice("15000");
		
		product.setCategory_id(",fasfa");
		
		product.setSupplier_id("SUP001");*/
		
		//System.out.println(product.getId());

		/*productDAO.saveOrUpdate(product);
		System.out.println("c9");
		System.out.println("Saved or Update Successfully");*/
		/*
		List<Product> list = productDAO.list();
		for(Product p : list)
		{
			System.out.println(p.getId() + ":" + p.getName() + ":" + p.getDescription() + ":" + p.getPrice());
			System.out.println(p.getCategory_id() + ":" + p.getSupplier_id());
		}*/

	
	/*ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

	Product product = (Product) context.getBean("product");

	product.setId("PR001");



	
	System.out.println(product.getId());

	productDAO.delete(product);
	
	System.out.println("Product deleted successfully");*/
	}

}