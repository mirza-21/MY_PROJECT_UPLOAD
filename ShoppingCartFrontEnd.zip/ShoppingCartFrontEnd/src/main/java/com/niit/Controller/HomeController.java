package com.niit.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

@Controller
public class HomeController {
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	User user;
	
	@RequestMapping("/")
	public ModelAndView showlandingpage() {
		System.out.println("h1");

		ModelAndView mv = new ModelAndView("home");
		System.out.println("h2");
		return mv;
	}
	@RequestMapping("home")
	public ModelAndView showHome() {

		ModelAndView mv = new ModelAndView("home");

		return mv;
	}
	
	@RequestMapping("/admin")
	public ModelAndView showAdmin() {
		
 
		ModelAndView mv = new ModelAndView("adminhome");
		mv.addObject("InAdminPage", "true");
	
		return mv;
	}

	@RequestMapping("/login")
	public ModelAndView showLogin(@RequestParam (value="error", required = false) String error,
			@RequestParam (value="logout", required = false) String logout,Model model ) 
	{

		if(error != null){
			model.addAttribute("error", "Invalid username and password");
		}
		
		if(logout != null)
			model.addAttribute("msg", "You have been logged out Successfully");
		   ModelAndView mv = new ModelAndView("login");

		return mv;
	}
	
	@RequestMapping("/newuser")
	public ModelAndView showAdminPage() {
		
 
		ModelAndView mv = new ModelAndView("register");
		
	
		return mv;
	}

	
	
	
	@RequestMapping("/contact")
	public ModelAndView showcontact() {

		ModelAndView mv = new ModelAndView("contact");

		return mv;
	}
	
	
	@RequestMapping("/aboutus")
	public ModelAndView showaboutus() {

		ModelAndView mv = new ModelAndView("aboutus");

		return mv;
	}

	
}