package com.niit.Controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.User;

@Controller
public class UserController {

	@Autowired
	UserDAO userDAO;

	@Autowired
	User user;

	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private Category category;

	@Autowired
	private SupplierDAO supplierDAO;

	@Autowired
	private Supplier supplier;

	@Autowired
	private ProductDAO productDAO;

	@Autowired
	private Product product;

	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public ModelAndView login(Principal principal, HttpServletRequest request, Model model) {
		ModelAndView mv;
		String name = principal.getName();
		System.out.println(name);
		String id = userDAO.getUsername(name);
		System.out.println(id);

		if (request.isUserInRole("ROLE_ADMIN")) {

			mv = new ModelAndView("adminhome");
			mv.addObject("loggedIn", true);
			System.out.println("adminhome");
			mv.addObject("username", name);

			return mv;

		}

		else {
			mv = new ModelAndView("userhome");
			model.addAttribute("product", new Product());
			model.addAttribute("category", new Category());
			model.addAttribute("supplier", new Supplier());
			model.addAttribute("productList", this.productDAO.list());
			model.addAttribute("categoryList", this.categoryDAO.list());
			model.addAttribute("supplierList", this.supplierDAO.list());
			mv.addObject("username", name);
			mv.addObject("loggedIn", true);

			return mv;
		}
	}

	@RequestMapping("/register")
	public ModelAndView registerUser(@RequestParam("password") String password,
			@RequestParam("repassword") String repassword, @RequestParam("name") String name,
			@RequestParam("id") String id, @RequestParam("email") String email,
			@RequestParam("mobile") String mobile) {
		ModelAndView mv;
		String message = null;
		if (password.equals(repassword)) {
			user.setId(id);
			user.setPassword(password);
			user.setName(name);
			user.setEmail(email);
			user.setMobile(mobile);
			if (id.contains("mirza21")) {
				user.setEnabled(true);
				user.setRole("ROLE_ADMIN");
			} else {
				user.setEnabled(true);
				user.setRole("ROLE_USER");
			}
			userDAO.saveOrUpdate(user);
			message="Login to Continue";
			mv = new ModelAndView("login");
		} else {
			message = "Passwords does not match";
			mv = new ModelAndView("login");
		}
		mv.addObject("message", message);
		return mv;
	}
		
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session) {
		ModelAndView mv = new ModelAndView("loggedOut");
		System.out.println("logoutpage");
		session.invalidate();
		session = request.getSession(true);
				
		mv.addObject("loggedOut", "true");
	
		return mv;
	 }
	
	@RequestMapping("/error")
	public String getError(Model model,HttpServletRequest request)
	{
		String name=request.getParameter("error");
		model.addAttribute("username", name);
		return "error";
	}
	
	@RequestMapping("/userhome")
	public ModelAndView showuser(Principal principal,HttpServletRequest request,Model model) 
	{
		
		ModelAndView mv;
		String name=principal.getName();
		System.out.println(name);
		String username= userDAO.getUsername(name);
		System.out.println(username);
		mv=new ModelAndView("home");
		model.addAttribute("product", new Product());
		model.addAttribute("category", new Category());
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		mv.addObject("username",name);
		mv.addObject("loggedIn",true );
		
	
		return mv;
	}
}
